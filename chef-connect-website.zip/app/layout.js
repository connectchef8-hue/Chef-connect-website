export const metadata = { title: "Chef Connect" };
export default function RootLayout({ children }) {
 return <html><body>{children}</body></html>
}