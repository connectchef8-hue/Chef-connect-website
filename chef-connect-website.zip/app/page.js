export default function Home() {
  const roles = ["Executive Chef","Sous Chef","CDP","Commis Chef","Tandoor Chef","Chinese Chef","South Indian Cook","Bakery Chef","Pizza Chef","Shawarma Specialist","Kitchen Helpers","Utility Staff"];
  return (
    <main style={{background:"#000",color:"#fff",minHeight:"100vh",fontFamily:"Arial, sans-serif",padding:"20px"}}>
      <section style={{textAlign:"center",padding:"60px 20px"}}>
        <h1 style={{fontSize:"56px"}}><span style={{color:"#d4af37"}}>CHEF</span> CONNECT</h1>
        <p>Connecting Kitchens with Talent</p>
        <p>Kitchen Setup & Chef Placement Consultancy • Serving Across India</p>
        <a href="https://wa.me/919177397781">Hire Staff on WhatsApp</a>
      </section>
      <section><h2>Roles We Provide</h2><ul>{roles.map(r=><li key={r}>{r}</li>)}</ul></section>
      <section><h2>Contact</h2><p>Shaik Siddiq Ahmed | Founder / Director</p><p>chefconnect8@gmail.com</p></section>
    </main>
  )
}